# -*- coding: utf-8 -*-
"""
Created on Mon May 20 12:34:31 2019
@file: DragonBall.py
@description: Video joc dessenvolupat amb la llibreria "pygame" amb el mòdul d'encap-
sulació de les classes, carregar i redimensió dinàmica de les imatges, amb formats
png, jpg, jpng,gif. Segon paquet de l'aplicació BBDD on tenim els registres de les
puntuacions del nostres jugadors, suportable per 1 o 2 jugadors en el mateix temps 
amb nombres de vides incrementables per cada un d'ells 
@author: Gilbert Viader
"""
import pygame
import sqlite3
import random
import datetime
import time
from pygame.locals import *
"""
importarem les llibreries de python que necessitarem per soportar els mètodes d'aquestes
amb ordre descendent d'importància en el comportament de l'aplicació
"""
random.seed()
"""
recollirem un nou valor del qual la sèrie de nombres aleatòria sempre serà nova, evitarem 
monotomies del nostre joc, en efecte sorpresa de les figures enemigues.
"""
amplada_Pantalla = 800
alçada_Pantalla = 600
"""
inicialització de les variable globals del programa
"""
class Jugador1 (self) :
    """
    creació de la classe per el jugador 1, on emprearem els mètodes de posició
    """
    def __init__ (self) :
        """
        creació del constructor de la classe
        """
        pass
    def actualJuga (self) :
        """
        creació del mètode per l'actualització del jugador
        """
        pass
class Projectil1 (self) :
    """
    creació de la classe del projectil per el jugador 1, 
    """
    def __init__ (self) :
        """
        creació del constructor de la classe
        """
        pass
    def actualProj (self) :
        """
        creació del mètode per l'actualització del jugador
        """
        pass
class Jugador2 (self) :
    """
    creació de la classe per el jugador 2, on emprearem els mètodes de posició
    """
    def __init__ (self) :
        """
        creació del constructor de la classe
        """
        pass
    def actualJuga (self) :
        """
        creació del mètode per l'actualització del jugador
        """
        pass
class Projectil2 (self) :
    """
    creació de la classe del projectil per el jugador 2, 
    """
    def __init__ (self) :
        """
        creació del constructor de la classe
        """
        pass
    def actualProj (self) :
        """
        creació del mètode per l'actualització del jugador
        """
        pass
class Enemic1 (self) :
    """
    creació de la classe per el enemic 1, on emprearem els mètodes de posició
    """
    def __init__ (self) :
        """
        creació del constructor de la classe
        """
        pass
    def actualJuga (self) :
        """
        creació del mètode per l'actualització de l'enemic 1
        """
        pass
class EnemicPro1 (self) :
    """
    creació de la classe del projectil per el enemicPro 1, 
    """
    def __init__ (self) :
        """
        creació del constructor de la classe
        """
        pass
    def actualProj (self) :
        """
        creació del mètode per l'actualització de l'enemic 1
        """
        pass
class Enemic2 (self) :
    """
    creació de la classe per el enemic 2, on emprearem els mètodes de posició
    """
    def __init__ (self) :
        """
        creació del constructor de la classe
        """
        pass
    def actualJuga (self) :
        """
        creació del mètode per l'actualització de l'enemic 2
        """
        pass
class EnemicPro2 (self) :
    """
    creació de la classe del projectil per el enemicPro 2, 
    """
    def __init__ (self) :
        """
        creació del constructor de la classe
        """
        pass
    def actualProj (self) :
        """
        creació del mètode per l'actualització de l'enemic 2
        """
        pass
class Bolesdrac (self) :
    """
    creació de la classe de les boles de drac on ens recuperarem amb increments
    de vida
    """
    def __init__ (self) :
        """
        creació del constructor de la classe
        """
        pass
    def actualBole (self) :
        """
        creació del mètode per l'actual posició de la bola de drac
        """
        pass
    
class Joc (object) :
    """
    crearem la classe on es desenvoluparà el joc passant com a paràmetre
    un objecte el qual l'encapsulat de la class serà destruit quan sortim d'ella
    """
    def __init__ (self) :
        """
        crearem el constructor de la classe amb la inicialització del seus atributs
        """
        pass
    def procesEvents (self) :
        """
        crearem el mètode on tenim tots els esdeveniments de la del joc en definions
        de tecles de control
        """
        pass
    def logicaExecutar (self) :
        """
        crearem el mètode on aniran fer actualitzacions de les noves posicions
        del objectes 
        """
        pass
    def visualPantalla (self) :
        """
        crearem el mètode per la visualtizatció de les continues modificacions dels
        objectes del joc
        """
        pass
    def visualMenu (self) :
        """
        crearem el mètode de visualització de la portada interactiva
        """
        
def main():
    """
    Funció principal del programa.
    """
    pygame.init() #inicialització de la pantalla del joc
    dimensions = [alçada_Pantalla, amplada_Pantalla]
    pantalla = pygame.display.set_mode(dimensions)
     
    pygame.display.set_caption("Bola de Drac Z")
    #pygame.mouse.set_visible(False)
    fer = False
    sortir = False
    temps = pygame.time.Clock()
    joc = Joc() # Crearem una instància de la classe Joc

    while not fer :     # Bucle principal metres el boolean sigui False       
        
        while not sortir : # Bucle aniuat metres sortir sigui False
            # crida del mètode d'entrada d'esdeveniment per entrades
            fer = joc.procesEvents()  
            # crida del mètode per les noves posiciones dels objets i
            # ens comprobarà les coal·lissions
            joc.logicaExecutar()
            # Dibuixar el moment actual per observar tots els canvs
            joc.visualPantalla(pantalla)         
            # farem 60 cop en un segon el bucle d'esdeveniments
            temps.tick(60) 
    #crida de la funció de la portada iteractiva
    pygame.visualMenu(pantalla)
    """
    carregarem el menu principal del joc per escollir opcions per nova partida
    """
    pygame.display.update() #guardar noves dades de la pantalla        
    pygame.quit() # tancarem la finestre pygame
    quit() # sortirem de python 3.7
 
# Crida de la funció principal i començarem el joc
if __name__ == "__main__":
     
    main() # funció principal main()
        